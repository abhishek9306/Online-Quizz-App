from flask import Flask,redirect,url_for,render_template,session,request,json
import requests
from random import shuffle

app=Flask(__name__)
app.secret_key='random string'

given_ans = []
correct_ans = []

@app.route('/home')
def home():
    if 'email'  in session:
        return render_template('home.html')
    else:
        return render_template('loginpage.html')

@app.route('/<int:id>')
def gernal(id):
    if 'email' not in session:
        return render_template('loginpage.html')
    else:
        data = getdata(id)
        answers = []
        questions = []
        for i in data['results']:
            new_list = []
            for j in i['incorrect_answers']:
                new_list.append(j)
            new_list.append(i['correct_answer'])
            correct_ans.append(i['correct_answer'])
            shuffle(new_list)
            answers.append(new_list)
            questions.append(i['question'])
        return render_template('gernal.html',answers=answers,questions=questions)

def getdata(id):
        data = json.loads(
        requests.get("https://opentdb.com/api.php?amount=10&category="+str(id)+"&difficulty=easy&type=multiple").text)
        print(data)
        return data

@app.route('/loginpage')
def login():
    if 'email' not in session:
        return render_template('loginpage.html')
    else:
        return render_template('home.html')

@app.route('/validate',methods=['POST'])
def validate():
    email=request.form['email']
    password=request.form['pass']
    if (email=='abc@gmail.com' and password=='123'):
        session['email']=email
        return redirect('/home')
    else:
        return redirect('/login')

@app.route('/marks',methods=['POST'])
def marks():
    for i in range(10):
        ans = request.form[str(i)]
        given_ans.append(ans)
    count = 0
    for i in range(10):
        if correct_ans[i] == given_ans[i]:
            count +=1
    return render_template('marks.html',count=count)

@app.route('/logout')
def logout():
    session.pop('email','non')
    return redirect('/loginpage')

if __name__=='__main__':
    app.run(debug=True)
# for i in range('questions'):
